/**
 * Created by jt on 2018-12-09.
 */
class GroovyHello {

    static void main(String[] args) {
        JavaHelloWorld javaHelloWorld = new JavaHelloWorld()

        println javaHelloWorld.hello
    }
}
