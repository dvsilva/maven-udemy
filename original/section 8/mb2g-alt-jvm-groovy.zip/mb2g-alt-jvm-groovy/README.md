# Apache Maven: Beginner to Guru

This respository contains code examples for the online course [Apache Maven: Beginner to Guru.](https://www.udemy.com/draft/2043700/?couponCode=GITHUB_REPO)

# Alternate JVM Languages in Maven

This repository has examples of using Maven to compile popular alternate JVM Languages.

## Groovy Example

This example use the [Groovy Eclipse Plugin](https://github.com/groovy/groovy-eclipse/wiki/Groovy-Eclipse-Maven-plugin) 
to compile Groovy with Java.
