fun main(args : Array<String>) {

    val hi = JavaHelloWorld()

    println(hi.hello)
}