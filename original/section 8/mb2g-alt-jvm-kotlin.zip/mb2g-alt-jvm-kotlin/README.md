# Apache Maven: Beginner to Guru

This respository contains code examples for the online course [Apache Maven: Beginner to Guru.](https://www.udemy.com/draft/2043700/?couponCode=GITHUB_REPO)

# Alternate JVM Languages in Maven

This repository has examples of using Maven to compile popular alternate JVM Languages.

## Kotlin with Maven

Please see documentation on configuring Maven to support Kotlin [here](https://kotlinlang.org/docs/reference/using-maven.html)
