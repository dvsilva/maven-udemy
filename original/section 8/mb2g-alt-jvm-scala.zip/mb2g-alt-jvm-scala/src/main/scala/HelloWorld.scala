class HelloWorld {
  def main(args: Array[String]): Unit = {
    val hi = new JavaHelloWorld

    println(hi.getHello)
  }
}
