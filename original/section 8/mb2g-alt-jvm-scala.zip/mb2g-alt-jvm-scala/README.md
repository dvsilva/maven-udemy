# Apache Maven: Beginner to Guru

This respository contains code examples for the online course [Apache Maven: Beginner to Guru.](https://www.udemy.com/draft/2043700/?couponCode=GITHUB_REPO)

# Alternate JVM Languages in Maven

This repository has examples of using Maven to compile popular alternate JVM Languages.

# Scala example using Maven

NOTE: Project is currently not working. At time of writing Scala does not support
Java 11 to be updated in the future.
