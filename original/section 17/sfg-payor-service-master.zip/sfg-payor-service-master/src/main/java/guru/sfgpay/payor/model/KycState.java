package guru.sfgpay.payor.model;

/**
 * Created by jt on 2018-12-07.
 */
public enum KycState {
    FAILED_KYC, PASSED_KYC, REQUIRES_KYC;
}
