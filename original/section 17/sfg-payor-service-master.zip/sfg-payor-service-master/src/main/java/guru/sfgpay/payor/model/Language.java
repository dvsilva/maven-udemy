package guru.sfgpay.payor.model;

/**
 * Created by jt on 2018-12-07.
 */
public enum  Language {
    EN, FR
}
