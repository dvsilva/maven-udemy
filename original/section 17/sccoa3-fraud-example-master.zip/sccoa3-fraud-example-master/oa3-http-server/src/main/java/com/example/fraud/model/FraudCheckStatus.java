package com.example.fraud.model;

public enum FraudCheckStatus {
	OK, FRAUD
}
