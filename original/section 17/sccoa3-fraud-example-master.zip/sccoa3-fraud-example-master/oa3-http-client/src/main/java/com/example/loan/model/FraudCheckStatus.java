package com.example.loan.model;

public enum FraudCheckStatus {
	OK, FRAUD
}
