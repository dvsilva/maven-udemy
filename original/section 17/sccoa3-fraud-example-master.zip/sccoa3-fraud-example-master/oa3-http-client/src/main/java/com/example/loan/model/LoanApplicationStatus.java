package com.example.loan.model;

public enum LoanApplicationStatus {
	LOAN_APPLIED, LOAN_APPLICATION_REJECTED
}
