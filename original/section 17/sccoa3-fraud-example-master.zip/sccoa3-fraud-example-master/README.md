# Spring Cloud Contract OA3 Fraud Client Example

This repository contains an example project using Spring Cloud Contact
with Contracts defined in Open API 3.0

For more information about using Open API 3.0 to define consumer driven 
contracts for Spring Cloud Contract see this [project on GitHub](https://github.com/springframeworkguru/spring-cloud-contract-oa3). 