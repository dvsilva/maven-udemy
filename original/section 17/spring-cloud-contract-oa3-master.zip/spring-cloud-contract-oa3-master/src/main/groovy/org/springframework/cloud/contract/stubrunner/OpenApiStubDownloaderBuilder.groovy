package org.springframework.cloud.contract.stubrunner

/**
 * Created by jt on 5/24/18.
 */
class OpenApiStubDownloaderBuilder {
}
