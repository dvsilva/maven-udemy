package guru.springframework.scc.oa3;

/**
 * Empty class for Java Doc - to keep Javadoc happy. Hit problems with
 * Groovy doc - this is a workaround to dependency hell.
 *
 * Created by jt on 2018-12-18.
 */
public class Placeholder {
}
