## YAML Contracts

The YAML files in this directory were copied from the SSC project and are used for 
testing the parsing of SSC contracts defined in YML. 

These files are here for reference only. The OA3 converter should have the same capabilities as the YAML DSL.

OA3 versions may be found in ../openapi. 