package guru.springframework.scc.oa3;

import org.junit.Test;

//@RunWith(SpringRunner.class)
//@SpringBootTest
public class SpringCloudContractOa3ApplicationTests {

    @Test
    public void contextLoads() {
    }

}
