[![CircleCI](https://circleci.com/gh/sfg-beer-works/sfg-brewery-bom.svg?style=svg)](https://circleci.com/gh/sfg-beer-works/sfg-brewery-bom)

# SFG Brewery BOM

Common BOM for SFG Beer Works - Brewery Projects