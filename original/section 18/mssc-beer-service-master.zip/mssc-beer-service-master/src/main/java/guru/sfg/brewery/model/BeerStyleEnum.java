package guru.sfg.brewery.model;

/**
 * Created by jt on 2019-05-12.
 */
public enum BeerStyleEnum {
    LAGER, PILSNER, STOUT, GOSE, PORTER, ALE, WHEAT, IPA, PALE_ALE, SAISON
}
