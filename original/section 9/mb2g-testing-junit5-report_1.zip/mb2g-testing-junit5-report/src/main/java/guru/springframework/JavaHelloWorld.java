package guru.springframework;

/**
 * Created by jt on 2018-12-09.
 */
public class JavaHelloWorld {

    public String getHello(){
        return "Hello World";
    }

}
