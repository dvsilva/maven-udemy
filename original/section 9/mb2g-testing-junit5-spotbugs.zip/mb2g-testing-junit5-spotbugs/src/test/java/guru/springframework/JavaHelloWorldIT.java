package guru.springframework;

import org.junit.jupiter.api.Test;

/**
 * Created by jt on 2018-12-14.
 */
public class JavaHelloWorldIT {

    @Test
    void myFauxIntegrationTest() {

        System.out.println("My IT Ran");
    }
}
