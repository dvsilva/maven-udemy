package guru.springframework;

import org.junit.jupiter.api.Test;

/**
 * Created by jt on 2018-12-09.
 */
public class JUnit5FauxTest {

    @Test
    void someTestforJUnit5() {
        System.out.println("I Ran....");
    }
}
