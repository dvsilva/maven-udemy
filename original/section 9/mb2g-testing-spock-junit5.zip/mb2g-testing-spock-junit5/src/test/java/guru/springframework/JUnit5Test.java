package guru.springframework;

import org.junit.jupiter.api.Test;

/**
 * Created by jt on 2018-12-12.
 */
public class JUnit5Test {

    @Test
    void exampleTest() {
    }
}
