package guru.springframework;

import org.junit.Test;

public class JavaHelloWorldTest {

    @Test
    public void getHello() {
    }
}