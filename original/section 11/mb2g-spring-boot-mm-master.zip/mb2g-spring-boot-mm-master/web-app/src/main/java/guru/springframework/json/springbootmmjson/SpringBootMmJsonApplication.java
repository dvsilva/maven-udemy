package guru.springframework.json.springbootmmjson;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootMmJsonApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootMmJsonApplication.class, args);
    }

}

