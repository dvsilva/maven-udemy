package guru.springframework.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mb2gSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(Mb2gSpringBootApplication.class, args);
	}

}

